console.log("clicked");

$(".navbutton").click(function(){
    $(".navselect").removeClass('navselect');
    $(this).attr('class', 'navselect navselect');
    var panelID = $(this).attr('data_panelid');
    $('html, body').animate({
        scrollTop: $('#'+panelID).offset().top
    }, 1000);
});


$("#fullpage").scroll(function(){
    console.log("scrolled.");
    /*$('html, body').animate({
        scrollTop: $(this).next().offset().top
    }, 1000);*/
});

