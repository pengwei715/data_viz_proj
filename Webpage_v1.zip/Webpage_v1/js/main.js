/**
 * Created by mariaschwarz on 4/5/16.
 */


// Will be used to the save the loaded JSON data
var allData = [];

// Date parser to convert strings to date objects
var parseDate = d3.time.format("%Y-%m-%-d").parse;

// Variables for the data instances
var syriaregion, eventdata, world, refugee_current, refugeecount;

// Variables for the visualization instances
var violencemap, timeline, actionmap;

// Databases for use in various visualizations
var actors, actorcolors, eventtypes, eventcolors;


// Start application by loading the data
loadData();

function loadData() {
    queue()
        .defer(d3.json, "data/world.json")
        .defer(d3.json, "data/syriaregion.json")
        .defer(d3.csv, "data/eventdata.csv")
        .defer(d3.csv, "data/refugee_current.csv")
        .defer(d3.csv, "data/refugees_syriaregion.csv")
        .await(function(error, data1, data2, data3, data4, data5){
            if (!error) {
                world = data1;
                syriaregion = data2;
                eventdata = data3;
                refugee_current = data4;
                refugeecount = data5;

                //console.log(eventdata);

                // Event data: Format time and convert all numbers to number values
                eventdata.forEach(function(d){
                    d.Event_ID = parseFloat(d.Event_ID);
                    d.CAMEO_Code = parseFloat(d.CAMEO_Code);
                    d.Intensity = parseFloat(d.Intensity);
                    d.Latitude = parseFloat(d.Latitude);
                    d.Longitude = parseFloat(d.Longitude);
                    d.Date = d3.time.format("%m/%d/%y").parse(d.Event_Date);
                    d.Year = parseFloat(d3.time.format("%Y")(d.Date));
                });
                eventdata.sort(function(a,b){
                    return a.Date - b.Date;
                });
                eventdata = eventdata.filter(function(d){return d.Date >= parseDate("2011-03-15");});


                // Refugee timeline (for violencemap)
                refugeecount.forEach(function(d){
                    d.Value = parseFloat(d.Value);
                    d.Date = d3.time.format("%y/%m/%d").parse(d.Date);
                });

                refugeecount = d3.nest()
                    .key(function(d) { return d.Code; })
                    //.key(function(d) { return d.Date; })
                    .rollup(function(d) { return d; })
                    .map(refugeecount);


                // Refugee current
                refugee_current.forEach(function(d){
                    d.refugee = +d.refugee;
                    d.month = +d.month;
                    d.year = +d.year;
                    d.gdppc = +d.gdppc;
                    d.population = +d.population;
                    d.per_gdppc = +d.per_gdppc;
                    d.per_1000pop = +d.per_1000pop;
                });


                // Get unique names of actors & assign colorscale to it (for use in ViolenceMap and ActorCord)
                actors = d3.map(eventdata, function(d){return d.Source_Sector_General;}).keys();
                actors = actors.filter(function(d){return d != ""});
                actorcolors = d3.scale.ordinal().domain([actors]).range(colorbrewer["Paired"]["8"]);

                eventtypes = d3.map(eventdata, function(d){return d.Event_Description_General;}).keys();
                eventcolors = d3.scale.ordinal().domain([eventtypes]).range(colorbrewer["Accent"]["8"]);

                createVis();
            };
            })};



function createVis() {
    // TO-DO: Instantiate visualization objects here
    //violencemap = new ViolenceMap("violencemap", syriaregion, eventdata, refugeecount);
    //timeline = new Timeline("timeline", eventdata);
    actionmap = new ActionMap("actionmap", world, refugee_current);
}



function brushed_violencemap() {

    var duration = 10,
        maxstep = d3.max(violencemap.eventdata, function(d){return d.Date;});

    // This is what happens when the play button is clicked
    if (violencemap.clickevent == true) {

        if (violencemap.running == true) {
            $("#playviolence").html("<i class='fa fa-play-circle fa-4x'></i>");
            violencemap.running = false;
            clearInterval(timer);
            violencemap.clickevent = false;
            timeline.clickevent = false;}

        else if (violencemap.running == false) {
            violencemap.clickevent = false;
            timeline.clickevent = false;
            $("#playviolence").html("<i class='fa fa-pause-circle fa-4x'></i>");
            timer = setInterval( function(){
                if (violencemap.currentTime < maxstep){
                    violencemap.currentTime = d3.time.day.offset(violencemap.currentTime,1);
                    timeline.currentTime = violencemap.currentTime;
                    violencemap.wrangleData();
                    timeline.handle.attr("x", timeline.xContext(violencemap.currentTime));
                    timeline.wrangleData();
                }
                else {
                    violencemap.currentTime = violencemap.startvalue;
                    $("#playviolence").html("<i class='fa fa-play-circle fa-3x'></i>");
                    violencemap.running = false;
                    console.log(violencemap.currentTime);
                    clearInterval(timer);
                }
            }, duration);
            violencemap.running = true;
        }
    }

    // This is what happens when the slider is being used
    else {
        /*
         if (timeline.brushcounter==0){
         console.log("we are here");
         timeline.brushcounter +=1;
         timer = setInterval( function(){}, duration);}
         else {clearInterval(timer);}*/

        clearInterval(timer);

        if (d3.event.sourceEvent) { // not a programmatic event
            value = timeline.xContext.invert(d3.mouse(this)[0]);
            timeline.brush.extent([value, value]);
            timeline.currentTime = timeline.brush.extent()[0];
            violencemap.currentTime = timeline.brush.extent()[0];
            $("#playviolence").html("<i class='fa fa-play-circle fa-4x'></i>");
            violencemap.running = false;
            violencemap.wrangleData();
            timeline.handle.attr("x", timeline.xContext(value));
            timeline.wrangleData();
            //console.log(timeline.brush.extent());
        }
    }
}

