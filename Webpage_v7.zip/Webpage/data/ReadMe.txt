UNHCR: 
—US has two sources: EOIR and INS/DHS, in our analysis, we kept INS/DHS
—Serbia and Kosovo is combined in refugee data. Split into Serbia and Kosovo but kept the total value for both countries. 
—England: Add SCT and WLS for England
—Ireland: Add NIR (North Ireland)
—Liechtenstein, 2009 GDP per capita: 114,802.7	
-Cyprus: ADD CYN to Cyprus
