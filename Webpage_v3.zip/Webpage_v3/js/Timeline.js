/******** Designer Maria Schwarz ********/


Timeline = function(_parentElement, _data){
	this.parentElement = _parentElement;
	this.eventdata = _data;

	var iso = d3.time.format.iso;


	// Create aggregate data by time of year
	this.eventtimeline = d3.nest()
		.key(function(d){return d.Date;})
		.rollup(function(d){return d.length})
		.entries(this.eventdata);

	this.eventtimeline.forEach(function(d){
		d.key = iso.parse(d.key);
	});


	// -------------------------------------------------------------------------
	// Create a cumulative and a single day version  - to switch between views
	// -------------------------------------------------------------------------

	var nest = this.eventtimeline;
	var nest = nest.map(function(d) {
		var filtered = nest.filter(function(v){return v.key <= d.key;});
		return {key: d.key, values: d3.sum(filtered, function(h){return h.values;})};
	});

	this.eventtimelinebyday = this.eventtimeline;
	this.eventtimelinecumulative = nest;

	this.eventtimeline = this.eventtimelinecumulative;



	// -------------------------------------------------------------------------
	// Initialize :)
	// -------------------------------------------------------------------------

	this.initVis();
}


Timeline.prototype.initVis = function(){
	var vis = this;



	// -------------------------------------------------------------------------
	// SVG Drawing area
	// -------------------------------------------------------------------------

	vis.margin = {top: 10, right: 0, bottom: 20, left: 20};
	vis.width = $("#"+vis.parentElement).width() - vis.margin.left - vis.margin.right;
	vis.height = 80 - vis.margin.top - vis.margin.bottom;

	// SVG drawing area
	vis.svg = d3.select("#" + vis.parentElement).append("svg")
		.attr("width", vis.width + vis.margin.left + vis.margin.right)
		.attr("height", vis.height + vis.margin.top + vis.margin.bottom)
		.append("g")
		.attr("transform", "translate(" + vis.margin.left + "," + vis.margin.top + ")");

	// Overlay with path clipping
	vis.svg.append("defs").append("clipPath")
		.attr("id", "clip")
		.append("rect")
		.attr("width", vis.width)
		.attr("height", vis.height);


	// -------------------------------------------------------------------------
	// Scales and axes
	// -------------------------------------------------------------------------
	vis.x = d3.time.scale()
		.range([0, vis.width])
		.domain(d3.extent(vis.eventtimeline, function(d) { return d.key; }));
	//.domain(d3.exent(vis.eventtimeline, function(d) { return iso.parse(d.key); }));

	vis.y = d3.scale.linear()
		.range([vis.height, 0])
		.domain([0, d3.max(vis.eventtimeline, function(d) { return d.values; })]);

	//console.log(vis.x.domain());

	vis.xAxis = d3.svg.axis()
		.scale(vis.x)
		.orient("bottom")
		.tickFormat(d3.time.format("%b-%y"));

	// -------------------------------------------------------------------------
	// Path generators
	// -------------------------------------------------------------------------

	// SVG area path generator: baseline
	vis.area = d3.svg.area()
		.x(function(d) { return vis.x(d.key); })
		//.x(function(d) { return vis.x(iso.parse(d.key)); })
		.y0(vis.height)
		.y1(function(d) { return vis.y(d.values); });

	vis.svg.append("path")
		.datum(vis.eventtimeline)
		.attr("class", "baselinearea")
		.attr("fill", "darkgrey")
		.attr("d", vis.area);


	// SVG area path generator: overlay (time passed; will be updated with data wrangling)
	vis.areaselect = d3.svg.area()
		.x(function(d) { return vis.x(d.key); })
		//.x(function(d) { return vis.x(iso.parse(d.key)); })
		.y0(vis.height)
		.y1(function(d) { return vis.y(d.values); });

	vis.svg.append("path")
		.datum(vis.eventtimeline)
		.attr("class", "timelineoverlay")
		.attr("fill", "red")
		.attr("d", vis.areaselect);



	// -------------------------------------------------------------------------
	// Initialize brush event
	// -------------------------------------------------------------------------

	vis.brushcounter = 0;

	vis.xContext = d3.time.scale()
		.range([0,vis.width])
		.domain(d3.extent(vis.eventtimeline, function(d) { return d.key; }));
	//.domain(d3.extent(vis.eventtimeline, function(d) { return iso.parse(d.key); }));

	vis.brush = d3.svg.brush()
		.x(vis.xContext)
		.extent([0, 0])
		.on("brush", brushed_violencemap);



	// TO-DO: Append brush component here

	vis.slider = vis.svg.append("g")
		.attr("class", "slider")
		.call(vis.brush);

	vis.slider.selectAll(".extent,.resize")
		.remove();

	vis.slider.select(".background")
		.attr("height", vis.height);

	vis.handle = vis.slider.append("rect")
		.attr("class", "handle")
		//.attr("transform", "translate(0," + vis.height + ")")
		.attr("width", 2)
		.attr("height", vis.height)
		.attr("y", 0);


	vis.svg.append("g")
		.attr("class", "x-axis axis timeline-axis")
		.attr("transform", "translate(0," + vis.height + ")")
		.call(vis.xAxis);

	vis.wrangleData();
}



Timeline.prototype.wrangleData = function() {
	var vis = this;

	vis.displayData = vis.eventtimeline.filter(function(d){return d.key <= vis.currentTime;})

	vis.updateVis();
}


Timeline.prototype.updateVis = function(){
	var vis = this;

	//console.log(vis.brush.extent());
	//vis.slider;

	vis.svg.select(".timelineoverlay")
		.datum(vis.displayData)
		.attr("fill", "red")
		.attr("d", vis.areaselect);

}



