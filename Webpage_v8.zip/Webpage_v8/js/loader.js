$(".loader").hide(6000).delay(0);
$(".fadeOnLoad1").hide(0).delay(10000).fadeIn(1000);
$(".fadeOnLoad2").hide(0).delay(12000).fadeIn(1000);
$(".fadeOnLoad3").hide(0).delay(14000).fadeIn(1000);
$(".fadeOnLoad4").hide(0).delay(16000).fadeIn(1000);
$(".fadeOnLoad5").hide(0).delay(20000).fadeIn(1500);
$(".typeOnLoad").hide(0).delay(18000).fadeIn(1500);