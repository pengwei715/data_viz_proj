console.log("clicked");

$(".navbutton").click(function(){
    $(".navselect").removeClass('navselect');
    $(this).attr('class', 'navselect navbutton');
    var panelID = $(this).attr('data_panelid');
    $('html, body').animate({
        scrollTop: $('#'+panelID).offset().top
    }, 1000);
});


$("#fullpage").scroll(function(){
    //console.log("scrolled.");
    /*$('html, body').animate({
        scrollTop: $(this).next().offset().top
    }, 1000);*/
});

/*
$(".downbutton").click(function(){
    //console.log($(this).closest('.section').next('.section'));
    $('html, body').animate({
     scrollTop: $(this).closest('.section').next('.section').offset().top
     }, 1000);
});*/


/* Adjust navigation bar based on clicks */
$(".upbutton").click(function(){
    console.log("clicked up");
    console.log($(this).closest('.section').prev('.section'));
    //console.log($(this).closest('.section').next('.section'));
    $('html, body').animate({
        scrollTop: $(this).closest('.section').prev('.section').offset().top
    }, 1000);

    var ID = $(this).closest('.section').prev('.section').attr("id");
    var string = function(d){return ".navbutton[data_panelid='"+d+"']"};
    var input = string(ID);
    var ID2 = $(input).attr("id");
    $(".navselect").removeClass('navselect');
    $('#'+ID2).attr('class', 'navselect navbutton');
});

$(".downbutton").click(function(){
    console.log("clicked down");
    console.log($(this).closest('.section').next('.section'));
    $('html, body').animate({
        scrollTop: $(this).closest('.section').next('.section').offset().top
    }, 1000);

    var ID = $(this).closest('.section').next('.section').attr("id");
    var string = function(d){return ".navbutton[data_panelid='"+d+"']"};
    var input = string(ID);
    var ID2 = $(input).attr("id");
    $(".navselect").removeClass('navselect');
    $('#'+ID2).attr('class', 'navselect navbutton');
});

