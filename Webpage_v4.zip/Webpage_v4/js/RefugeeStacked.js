/******** Designer Lily Li ********/

RefugeeStacked = function(_parentElement, _campdata_total){
    this.parentElement = _parentElement;
    this.campdata_total = _campdata_total;
    this.displayData = []; // see data wrangling

    campdata_total.sort(function(a,b){
        return a.date - b.date;
    });

    //console.log(this.campdata_total);

    this.initVis();

};

RefugeeStacked.prototype.initVis = function() {
    var vis = this;

    // -------------------------------------------------------------------------
    // SVG Drawing area
    // -------------------------------------------------------------------------
    vis.margin = {top: 10, right: 5, bottom: 35, left: 43};
    vis.width = $("#" + vis.parentElement).width() - vis.margin.left - vis.margin.right;
    //vis.width =  100 - vis.margin.left - vis.margin.right;
    vis.height = 300 - vis.margin.top - vis.margin.bottom;

    // SVG drawing area
    vis.svg = d3.select("#" + vis.parentElement).append("svg")
        .attr("width", vis.width + vis.margin.left + vis.margin.right)
        .attr("height", vis.height + vis.margin.top + vis.margin.bottom)
        .append("g")
        .attr("transform", "translate(" + vis.margin.left + "," + vis.margin.top + ")");
    //.attr("transform", "translate(0,0)");

    // -------------------------------------------------------------------------
    // Overlay with path clipping
    // -------------------------------------------------------------------------
    vis.svg.append("defs").append("clipPath")
        .attr("id", "clip")
        .append("rect")
        .attr("width", vis.width)
        .attr("height", vis.height);

    // -------------------------------------------------------------------------
    // Scales and axes
    // -------------------------------------------------------------------------

    vis.x = d3.time.scale()
        .range([0, vis.width])
        .domain(d3.extent(vis.campdata_total, function(d) { return d.date; }));

    vis.y = d3.scale.linear()
        .range([vis.height, 0]);

    vis.xAxis = d3.svg.axis()
        .scale(vis.x)
        .orient("bottom")
        .tickFormat(d3.time.format("%b-%y"))
        .ticks(d3.time.month, 6);

    vis.yAxis = d3.svg.axis()
        .scale(vis.y)
        .orient("left")
        .tickFormat(d3.format(".1s"));

    vis.svg.append("g")
        .attr("class", "x-axis axis")
        .attr("transform", "translate(0," + vis.height + ")");

    vis.svg.append("g")
        .attr("class", "y-axis axis");

    // -------------------------------------------------------------------------
    // Initialize stack layout: Get all categories
    // -------------------------------------------------------------------------
    vis.selectValue = "level_1";
    vis.domaindict = {
        "level_1" : ["TUR","JOR","EGY","LBN","IRQ"],
        "level_2" : ["Ajlun Governorate", "Amman Governorate", "Anbar",	"Aqaba Governorate",
            "Balqa  Governorate", "Beirut",	"Bekaa", "Dispersed", "Dispersed2",	"Duhok", "Egypt",
            "Erbil", "Irbid Governorate", "Jarash Governorate",	"Karak Govenorate",	"Maan Governorate",
            "Madaba Governorate", "Mafraq Governorate",	"North Lebanon", "South Lebanon", "Sulaymaniyah",
            "Tafilah Govenorate", "Turkey", "Zarqa Govenorate"],
        "level_3" : ["Ajlun","Akre Settlement", "Al-Obaidi Camp", "Amman", "Anbar Non-Camp", "Aqaba", "Arbat Permanent Camp",
            "Azraq Camp", "Balqa", "Basirma Camp", "Beirut", "Bekaa", "Darashakran Camp", "Dispersed",
            "Dispersed2", "Domiz 1 Camp", "Domiz 2 Camp", "Duhok Non-Camp",	"Egypt", "Erbil Non-Camp",
            "Gawilan Camp",	"Irbid", "Jarash",	"Karak", "Kawergosk Camp",	"Maan",	"Madaba", "Mafraq",	"North Lebanon", "Qushtapa Camp", "South Lebanon",
            "Sulaymaniyah Non-Camp", "Tafilah",	"Turkey", "Zaatari Refugee Camp", "Zarqa"]
    };


    vis.colorScale = d3.scale.category20();

    vis.colorScale
        .domain(vis.domaindict[vis.selectValue]);

    vis.dataCategories = vis.colorScale.domain();

    // Rearrange data into layers
    // -------------------------------------------------------------------------
    // Level 1
    // -------------------------------------------------------------------------
    vis.transposedData = d3.nest().key(function(d) {return d.level_1; })
        .key(function(d){return d.date})
        .rollup(function(v) { return d3.mean(v, function(d) { return d.sum_1; }); })
        .entries(vis.campdata_total);

    var iso = d3.time.format.iso;

    vis.transposedData.forEach(function(d){
        d.values.forEach(function(v){
            v.key = iso.parse(v.key);
            v.y = v.values;
            delete v.values;
            v.Date = v.key;
            delete v.key;
        })
    });

    // -------------------------------------------------------------------------
    // Level 3
    // -------------------------------------------------------------------------
    vis.transposedData3 = d3.nest().key(function(d) {return d.level_3; })
        .key(function(d){return d.date})
        .rollup(function(v) { return d3.mean(v, function(d) { return d.sum_3; }); })
        .entries(vis.campdata_total);

    var iso = d3.time.format.iso;

    vis.transposedData3.forEach(function(d){
        d.values.forEach(function(v){
            v.key = iso.parse(v.key);
            v.y = v.values;
            delete v.values;
            v.Date = v.key;
            delete v.key;
        })
    });

    //console.log(transposedData);

    vis.stack = d3.layout.stack()
        .values(function(d) { return d.values;});

    //console.log(stack);

    vis.stackedData = vis.stack(vis.transposedData);

    //console.log(vis.stackedData);

    // -------------------------------------------------------------------------
    // Stacked area layout
    // -------------------------------------------------------------------------
    vis.area = d3.svg.area()
        .interpolate("bundle")
        .x(function(d) { return vis.x(d.Date);})
        .y0(function(d) { return vis.y(d.y0);})
        .y1(function(d) {return vis.y(d.y0 + d.y);});

    vis.area2 = d3.svg.area()
        .interpolate("basis")
        .x(function(d) {return vis.x(d.Date);})
        .y0(vis.y(0))
        .y1(function(d) {return vis.y(d.y)});

    // -------------------------------------------------------------------------
    // Tooltip placeholder
    // -------------------------------------------------------------------------
    vis.svg.append("g")
        .append("text")
        .attr("id","category")
        .attr("transform", "rotate(0)")
        .attr("y", 6)
        .attr("x", 20)
        .attr("dy", ".71em")
        .style("text-anchor", "start")
        .text("All");

    vis.filter = "";
    //console.log(vis.filter);

    d3.select("#level_1").on("click", function(){
        vis.selectValue = d3.select("#level_1").property("id");
        d3.select("#category").text("All");
        //console.log(vis.selectValue);
        vis.filter="";
        vis.wrangleData()});

    d3.select("#level_3").on("click", function(){
        vis.selectValue = d3.select("#level_3").property("id");
        d3.select("#category").text("All");
        //console.log(vis.selectValue);
        vis.filter="";
        vis.wrangleData()});

    vis.wrangleData();
};

RefugeeStacked.prototype.wrangleData = function() {
    var vis = this;

    vis.stackedData = (vis.selectValue == "level_1") ? vis.stack(vis.transposedData) :vis.stack(vis.transposedData3);

    // In the first step no data wrangling/filtering needed
    if (vis.filter == "") {vis.displayData = vis.stackedData}
    else {vis.displayData = vis.stackedData.filter(function(d) {return d.key == vis.filter})};

    //console.log(vis.displayData);


    // -------------------------------------------------------------------------
    // Define Brush
    // -------------------------------------------------------------------------

    /*
    vis.xContext = d3.time.scale()
        .range([0, vis.width])
        .domain(d3.extent(vis.campdata_total, function (d) {
            return d.date;
        }));

    var formatDate = d3.time.format("%b-%y");
    var mindate = d3.min(vis.campdata, function(d) {return d.date});

    vis.brush = d3.svg.brush()
        .x(vis.xContext)
        .extent([0, 0])
        .on("brush", brushed_refugeemap);

    vis.slider = vis.svg.append("g")
        .attr("class", "slider")
        .call(vis.brush);

    vis.slider.selectAll(".extent,.resize")
        .remove();

    vis.slider.select(".background")
        .attr("height", vis.height);

    vis.handle = vis.slider.append("g")
        .attr("class", "timeslidehandle");

    vis.handle.append("rect")
        .attr("width", 5)
        .attr("height", 15)
        .attr("y", vis.height / 2 -5 );

    vis.handle.append("text")
        .text(formatDate(mindate))
        .attr("fill", "black")
        .attr("transform", "translate(" + -15 + " ," + 15 + ")");
    */

    // Update the visualization
    vis.updateVis();

};

RefugeeStacked.prototype.updateVis = function() {
    var vis = this;

    // Update domain
    // Get the maximum of the multi-dimensional array or in other words, get the highest peak of the uppermost layer

    if(vis.filter=="") {
        vis.y.domain([0, d3.max(vis.displayData, function (d) {
            return d3.max(d.values, function (e) {
                return e.y0 + e.y;
            });
        })
        ]);
    } else {
        vis.y.domain([0, d3.max(vis.displayData[0].values,
            function(d) { return d.y; })]);
    };

    // Draw the layers
    vis.categories = vis.svg.selectAll(".area")
        .data(vis.displayData);

    vis.categories.enter().append("path")
        .attr("class", "area");

    vis.categories
        .style("fill", function(d) {
            return vis.colorScale(d.key);
        })
        .attr("d", function(d) {
            if (vis.filter=="") {
                return vis.area(d.values)
            } else { return vis.area2(d.values)
            }
        })
        .on("click", function(d){
            d3.select("#category").text(d.key);
            vis.filter = (vis.filter == d.key) ? "" : d.key;
            //console.log(vis.filter);
            vis.wrangleData();
        });

    // Update tooltip text
    vis.categories.exit().remove();

    vis.svg.select(".x-axis").transition().duration(500).call(vis.xAxis).attr("dy", "4.5em");
    vis.svg.select(".y-axis").transition().duration(500).call(vis.yAxis);

};