/**
 * Created by mariaschwarz on 4/5/16.
 */


// Will be used to the save the loaded JSON data
var allData = [];

// Date parser to convert strings to date objects
var parseDate = d3.time.format("%Y-%m-%-d").parse; //don't think this is correct
var formatDate = d3.time.format("%b-%y");

// Variables for the data instances
var syriaregion, eventdata, world, refugee_current, refugeecount,campdata,campdata_total; //changes made

// Variables for the visualization instances
var violencemap, timeline, actionmap, actorstacked, refugeemap, timeslide, refugeestacked; //changes made

// Databases for use in various visualizations
var actors, actorcolors, eventtypes, eventcolors;


// Start application by loading the data
loadData();

function loadData() {
    queue()
        .defer(d3.json, "data/world.json")
        .defer(d3.json, "data/syriaregion.json")
        .defer(d3.csv, "data/eventdata.csv")
        .defer(d3.csv, "data/refugee_current.csv")
        .defer(d3.csv, "data/refugees_syriaregion.csv")
        .defer(d3.csv, "data/campdata5.csv")
        .defer(d3.csv, "data/campdata8.csv")
        .await(function(error, data1, data2, data3, data4, data5, data6, data7){   //changes made
            if (!error) {
                world = data1;
                syriaregion = data2;
                eventdata = data3;
                refugee_current = data4;
                refugeecount = data5;
                campdata = data6;    // changes made
                campdata_total = data7; // changes made

                //console.log(eventdata);
                //console.log(campdata);

                // Event data: Format time and convert all numbers to number values
                eventdata.forEach(function(d){
                    d.Event_ID = parseFloat(d.Event_ID);
                    d.CAMEO_Code = parseFloat(d.CAMEO_Code);
                    d.Intensity = parseFloat(d.Intensity);
                    d.Latitude = parseFloat(d.Latitude);
                    d.Longitude = parseFloat(d.Longitude);
                    d.Date = d3.time.format("%m/%d/%y").parse(d.Event_Date);
                    d.Year = parseFloat(d3.time.format("%Y")(d.Date));
                });
                eventdata.sort(function(a,b){
                    return a.Date - b.Date;
                });
                eventdata = eventdata.filter(function(d){return d.Date >= parseDate("2011-03-15");});

                // Refugee timeline (for violencemap)
                refugeecount.forEach(function(d){
                    d.Value = parseFloat(d.Value);
                    d.Date = d3.time.format("%y/%m/%d").parse(d.Date);
                });

                refugeecount = d3.nest()
                    .key(function(d) { return d.Code; })
                    //.key(function(d) { return d.Date; })
                    .rollup(function(d) { return d; })
                    .map(refugeecount);


                // Refugee current
                refugee_current.forEach(function(d){
                    d.refugee = +d.refugee;
                    d.month = +d.month;
                    d.year = +d.year;
                    d.gdppc = +d.gdppc;
                    d.population = +d.population;
                    d.per_gdppc = +d.per_gdppc;
                    d.per_1000pop = +d.per_1000pop;
                });


                // Get unique names of actors & assign colorscale to it (for use in ViolenceMap and ActorCord)
                actors = d3.map(eventdata, function(d){return d.Source_Sector_General;}).keys();
                actors = actors.filter(function(d){return d != ""});
                actorcolors = d3.scale.ordinal().domain([actors]).range(colorbrewer["Paired"]["8"]);

                eventtypes = d3.map(eventdata, function(d){return d.Event_Description_General;}).keys();
                eventcolors = d3.scale.ordinal().domain([eventtypes]).range(colorbrewer["Accent"]["8"]);

                //changes made
                // Refugee bubble map
                campdata.forEach(function(d){
                    d.lati = +d.lati;
                    d.longti = +d.longti;
                    d.refugee = +d.refugee;
                    //d.date = d3.time.format("%Y/%m/%d").parse(d.date);
                    d.date = d3.time.format("%m/%d/%Y").parse(d.date);
                    //d.date = d3.time.format("%Y/%m").parse(d.date);
                });

                campdata.sort(function(a,b){
                    return a.date - b.date;
                });


                // Refugee stacked area chart
                campdata_total.forEach(function(d) {
                    d.lati = +d.lati;
                    d.longti = +d.longti;
                    d.refugee = +d.refugee;
                    d.sum = +d.sum;
                    d.sum_1 = +d.sum_1;
                    d.sum_2 = +d.sum_2;
                    d.sum_3 = +d.sum_3;
                    d.date = d3.time.format("%Y/%m/%d").parse(d.date);
                    //d.date = d3.time.format("%m/%d/%Y").parse(d.date);
                    //d.date = d3.time.format("%Y/%m").parse(d.date);
                });

                campdata_total.sort(function(a,b){
                    return a.date - b.date;
                });

                //console.log(campdata_total);

                createVis();
            };
            })};



function createVis() {
    // TO-DO: Instantiate visualization objects here
    //violencemap = new ViolenceMap("violencemap", syriaregion, eventdata, refugeecount);
    //timeline = new Timeline("timeline", eventdata);
    //actionmap = new ActionMap("actionmap", world, refugee_current);
    //actorstacked = new ActorStacked("actorstacked");

    // changes made
    refugeemap = new RefugeeMap("refugeemap", syriaregion, campdata);
    timeslide = new Timeslide("timeslide",campdata);
    refugeestacked = new RefugeeStacked("refugeestacked",campdata_total);
}


function brushed_refugeemap() {

    var duration = 0.5,
        maxstep = d3.max(refugeemap.campdata, function(d){return d.date;}),
        minstep = d3.min(refugeemap.campdata, function(d){return d.date;});

    // This is what happens when the play button is clicked
    if (refugeemap.clickevent == true) {

        //console.log("we have clicked the plaz button");

        if (refugeemap.running == true) {
            //console.log("the play button has been running");
            $("#playcamp").html("<i class='fa fa-play-circle fa-4x'></i>");
            refugeemap.running = false;
            clearInterval(timer);
            refugeemap.clickevent = false;
            timeslide.clickevent = false;
             }

        else
            if (refugeemap.running == false) {
                //console.log("the play button has not been running");
                //console.log(refugeemap);
                //console.log(timeslide);
                refugeemap.clickevent = false;
                timeslide.clickevent = false;
                $("#playcamp").html("<i class='fa fa-pause-circle fa-4x'></i>");
                timer = setInterval(function () {
                    if (refugeemap.currentTime < maxstep) {
                        refugeemap.currentTime = d3.time.day.offset(refugeemap.currentTime, 2);
                        timeslide.currentTime = refugeemap.currentTime;
                        refugeemap.wrangleData();
                        //console.log(typeof(efugeemap.currentTime));
                        timeslide.handle.select("rect").attr("x", timeslide.xContext(refugeemap.currentTime));
                        timeslide.handle.select("text").text(formatDate(refugeemap.currentTime));
                        timeslide.handle.select("text").attr("x", timeslide.xContext(refugeemap.currentTime));
                        /*
                        timeslide.handle.attr("x", timeslide.xContext(refugeemap.currentTime));
                        timeslide.timelegend.attr("x", timeslide.xContext(refugeemap.currentTime));
                        timeslide.timelegend.select("text").text(formatDate(refugeemap.currentTime));
                        console.log(formatDate(refugeemap.currentTime));
                        */
                        //console.log(timeslide.xContext(refugeemap.currentTime));
                        //timeslide.wrangleData();
                    }
                    else {
                        refugeemap.currentTime = refugeemap.startvalue;
                        //console.log(refugeemap.currentTime);
                        $("#playcamp").html("<i class='fa fa-play-circle fa-3x'></i>");
                        refugeemap.running = false;
                        //console.log(refugeemap.currentTime);
                        clearInterval(timer);
                    }
                }, duration);
                refugeemap.running = true;
            }
        }

        // This is what happens when the slider is being used
        else {

        clearInterval(timer);

        //console.log(clearInterval(timer));

        //console.log(d3.event.sourceEvent);

        if (d3.event.sourceEvent) { // not a programmatic event
            value = timeslide.xContext.invert(d3.mouse(this)[0]);
            timeslide.brush.extent([value, value]);
            if (timeslide.brush.extent()[0] < minstep) {
                timeslide.currentTime = minstep;
                value = minstep;
            }
            else if (timeslide.brush.extent()[0] > maxstep) {
                timeslide.currentTime = maxstep;
                value = maxstep;
            }
            else {
                timeslide.currentTime = timeslide.brush.extent()[0];
            }
            refugeemap.currentTime = timeslide.currentTime;
            $("#playcamp").html("<i class='fa fa-play-circle fa-4x'></i>");
            refugeemap.running = false;
            refugeemap.wrangleData();
            timeslide.handle.select("rect").attr("x", timeslide.xContext(refugeemap.currentTime));
            timeslide.handle.select("text").text(formatDate(refugeemap.currentTime));
            timeslide.handle.select("text").attr("x", timeslide.xContext(refugeemap.currentTime));
            //timeslide.wrangleData();
            //console.log(timeline.brush.extent());
        }
    }

};




function brushed_violencemap() {

    var duration = 2,
        maxstep = d3.max(violencemap.eventdata, function(d){return d.Date;}),
        minstep = d3.min(violencemap.eventdata, function(d){return d.Date;});

    // This is what happens when the play button is clicked
    if (violencemap.clickevent == true) {

        if (violencemap.running == true) {
            $("#playviolence").html("<i class='fa fa-play-circle fa-4x'></i>");
            violencemap.running = false;
            clearInterval(timer);
            violencemap.clickevent = false;
            timeline.clickevent = false;}

        else if (violencemap.running == false) {
            violencemap.clickevent = false;
            timeline.clickevent = false;
            $("#playviolence").html("<i class='fa fa-pause-circle fa-4x'></i>");
            timer = setInterval( function(){
                if (violencemap.currentTime < maxstep){
                    violencemap.currentTime = d3.time.day.offset(violencemap.currentTime,1);
                    timeline.currentTime = violencemap.currentTime;
                    violencemap.wrangleData();
                    timeline.handle.attr("x", timeline.xContext(violencemap.currentTime));
                    timeline.wrangleData();
                }
                else {
                    violencemap.currentTime = violencemap.startvalue;
                    $("#playviolence").html("<i class='fa fa-play-circle fa-3x'></i>");
                    violencemap.running = false;
                    //console.log(violencemap.currentTime);
                    clearInterval(timer);
                }
            }, duration);
            violencemap.running = true;
        }
    }

    // This is what happens when the slider is being used
    else {
        /*
         if (timeline.brushcounter==0){
         console.log("we are here");
         timeline.brushcounter +=1;
         timer = setInterval( function(){}, duration);}
         else {clearInterval(timer);}*/

        clearInterval(timer);

        if (d3.event.sourceEvent) { // not a programmatic event
            value = timeline.xContext.invert(d3.mouse(this)[0]);
            timeline.brush.extent([value, value]);
            if (timeline.brush.extent()[0]<minstep){
                timeline.currentTime = minstep;
                value = minstep;}
            else if (timeline.brush.extent()[0]>maxstep){timeline.currentTime = maxstep;
            value = maxstep;}
            else {timeline.currentTime = timeline.brush.extent()[0];}
            //timeline.currentTime = timeline.brush.extent()[0];
            violencemap.currentTime = timeline.currentTime;
            //violencemap.currentTime = timeline.brush.extent()[0];
            $("#playviolence").html("<i class='fa fa-play-circle fa-4x'></i>");
            violencemap.running = false;
            violencemap.wrangleData();
            timeline.handle.attr("x", timeline.xContext(value)-2);
            timeline.wrangleData();
            //console.log(timeline.brush.extent());
        }
    }
}

