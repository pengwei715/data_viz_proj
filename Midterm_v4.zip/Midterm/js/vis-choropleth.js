

// --> CREATE SVG DRAWING AREA
var width = 1000,
    height = 600;

var svg = d3.select("#chart-area").append("svg")
    .attr("width", width)
    .attr("height", height);

var projection = d3.geo.mercator()
    .scale(300)
    .translate([width / 2, height / 2]);

var path = d3.geo.path()
    .projection(projection);

var rateById = d3.map();

var color = d3.scale.quantize().range(["#feedde","#fdbe85","#fd8d3c","#e6550d","#a63603"]);

// Use the Queue.js library to read two files

queue()
  .defer(d3.json, "data/africa.topo.json")
  .defer(d3.csv, "data/global-malaria-2015.csv")
  .await(function(error, mapTopJson, malariaDataCsv){
      if (error) throw error;

      console.log(mapTopJson,malariaDataCsv);
    
    // --> PROCESS DATA
      var malariaData = malariaDataCsv.filter(function(el, index){
          return (el.WHO_region == "African");
      });

      console.log(malariaData);

      var africa = topojson.feature(mapTopJson, mapTopJson.objects.collection).features;
      console.log(africa);

      var malariaDataByCountryId = {};
      malariaData.forEach(function(d){
          malariaDataByCountryId[d.Code] = +d.UN_population;
      });

      console.log(malariaDataByCountryId);
      console.log(d3.extent(d3.values(malariaDataByCountryId)));

      svg.selectAll("path")
          .data(africa)
          .enter().append("path")
          .attr('class', 'mapTopJson')
          .attr("d", path)
          .style("fill",function(d){
          if (parseInt(malariaDataByCountryId[d.adm0_a3_is])< 386342) {
              console.log(malariaDataByCountryId[d.adm0_a3_is]);
              return "red";
          }
          else {
              return "blue"
          }});

          /*.style("fill", function(d) { return color(malariaDataByCountryId[d.adm0_a3_is]); });*/

          /*
          .style("fill", function(d) {
              if (malariaDataByCountryId[d.adm0_a3_is]) {
                  return color(malariaDataByCountryId[d.adm0_a3_is]);
              }
              else {
                  return "#ccc";
              }
              */

      // Update choropleth
    updateChoropleth();
  });
    

function updateChoropleth() {

  // --> Choropleth implementation

}

/*

 for (var i = 0; i < malariaData.length; i++) {
 var o = malariaData[i];
 o.adm0_a3_is = o.Code;
 delete o.Code;
 }


for (var i=0; i < malariaData.length; i++) {
    console.log(i);
    var malariaCountry = malariaData[i].Code;
    console.log("test:" + malariaCountry);
    var malariaValue = malariaData[i].UN_population;

    for (var j = 0; j < africa[j].length; j++) {
        var jsonCountry = africa[j].properties.adm0_a3_is;
        if (malariaCountry = jsonCountry) {
            africa[j].properties.value = malariaValue;
            break;
        };
    }
};
*/