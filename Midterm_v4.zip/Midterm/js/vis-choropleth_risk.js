var tooltip = {
    element: null,
    init: function() {
        this.element = d3.select("body").append("div").attr("class", "tooltip").style("opacity", 0);
    },
    show: function(t) {
        this.element.html(t).transition().duration(200).style("left", d3.event.pageX + 10 + "px").style("top", d3.event.pageY - 10 + "px").style("opacity", .9);
    },
    move: function() {
        this.element.transition().duration(30).ease("linear").style("left", d3.event.pageX + 10 + "px").style("top", d3.event.pageY - 10 + "px").style("opacity", .9);
    },
    hide: function() {
        this.element.transition().duration(500).style("opacity", 0)
    }};

tooltip.init();

function createRiskMap(flag){
  // --> CREATE SVG DRAWING AREA
  var width = 960;
      height = 600;

  var svg = d3.select("#chart-area").append("svg")
      .attr("width", width)
      .attr("height", height);

  var projection = d3.geo.mercator()
      .scale(300)
      .translate([width / 2, height / 2]);

  var path = d3.geo.path()
      .projection(projection);

  var rateById = d3.map();

  //var color = d3.scale.quantize().range(["#feedde","#fdbe85","#fd8d3c","#e6550d","#a63603"]);

  // Use the Queue.js library to read two files

  queue()
    .defer(d3.json, "data/africa.topo.json")
    .defer(d3.csv, "data/global-malaria-2015.csv",function(d) { 
        
        if(d.WHO_region == "African"){
          //console.log(d);
          if(flag != "highrisk"){
            rateById.set(d.Code, +d.At_risk); 
          }else{
            rateById.set(d.Code, +d.At_high_risk);
          }
      }
    })
    .await(function(error, mapTopJson, malariaDataCsv){
        if (error) throw error;

        console.log(mapTopJson,malariaDataCsv);
       
      //------------------------------------------

      var colorRange = (flag == "highrisk")? colorbrewer.RdGy["11"]: colorbrewer.Spectral["11"];
      var colorScale = d3.scale.threshold()
        .domain([10, 20, 30, 40,  50, 60, 70,80,90,100, 110]) 
        .range(colorRange);

      formatValue = d3.format(".0%");
      // A position encoding for the key only.
      var list = [10, 20, 30, 40,  50, 60, 70,80,90,100];
      for(var i=0;i<list.length;i++){
        list[i] = 50000000/100*list[i];
      }
      var x = d3.scale.linear()
          .domain([0, 50000000])
          .range([0, 600]);
      var xAxis = d3.svg.axis()
          .scale(x)
          .orient("bottom")
          .tickSize(13)
          .tickValues(list)
          .tickFormat(function(d) { return formatValue(d/50000000)});


/*      var vvv = colorScale.range().map(function(d, i) {
            return {
              x0: i ? x(colorScale.domain()[i - 1]) : x.range()[0],
              x1: i < colorScale.domain().length ? x(colorScale.domain()[i]) : x.range()[1],
              z: d
            };
          })
      console.log("vvv");
      console.log(vvv);
*/

      // key
      var g = svg.append("g")
          .attr("class", "key")
          .attr("transform", "translate(170,50)");

      g.selectAll("rect")
          .data(colorScale.range().map(function(d, i) {
              console.log(x(i*500000));
            return {
              x0: x(i*5000000), //colorScale.domain()[i] - 100 ,
              x1: x((i+1)*5000000), //colorScale.domain()[i] ,
              z: d
            };
          }))
        .enter().append("rect")
          .attr("height", 8)
          .attr("x", function(d) { return d.x0; })
          .attr("width", function(d) { return d.x1 - d.x0; })
          .style("fill", function(d) { return d.z; });

      g.call(xAxis).append("text")
          .attr("class", "caption")
          .attr("y", -6)
          .text("risk of malaria in Africa");  
      // key end    
      //------------------------------------    
      // --> PROCESS DATA
/*        var malariaData = malariaDataCsv.filter(function(el, index){
            return (el.WHO_region == "African");
        });

        console.log("malariaData:");
        console.log(malariaData);*/

        var africa = topojson.feature(mapTopJson, mapTopJson.objects.collection).features;
        console.log("africa:");
        console.log(africa);

/*        var malariaDataByCountryId = {};
        malariaData.forEach(function(d){
            malariaDataByCountryId[d.Code] = +d.UN_population;
        });
*/
/*        console.log(malariaDataByCountryId);
        console.log(d3.extent(d3.values(malariaDataByCountryId)));
*/

        var numFormat = d3.format(".0%");
        var countries = svg.selectAll("path")
            .data(africa)
            .enter().append("path")
            .attr('class', 'mapTopJson')
            .attr("d", path)
            .style("fill",function(d){
                return colorScale(rateById.get(d.properties.adm0_a3_is)); 
                //return "#ccc"
            }).attr( "stroke", "#C0B9B9" )
            .on("mouseover", function(d){
/*                console.log("d:");
                console.log(d.properties.adm0_a3_is);*/

                var risk = rateById.get(d.properties.adm0_a3_is);
                if(typeof risk === "undifuned" || 
                    isNaN(risk)
                  ){
                  tooltip.show("<b>"+d.properties.name+ "</b>" + "<br>" + "Risk: No Data" );
                console.log(d.properties.adm0_a3_is);
                }else{
                  tooltip.show("<b>"+d.properties.name+ "</b>" + "<br>" + "Risk: " + numFormat(risk/100)); 
                }
                /*var pop = (typeof rateById.get(d.properties.adm0_a3_is) === "undifuned" || typeof rateById.get(d.properties.adm0_a3_is) === "NaN")?   "No Data":rateById.get(d.properties.adm0_a3_is) ;
                

                tooltip.show("<b>"+d.properties.name+ "</b>" + "<br>" + "Population: " + numFormat(pop/100)); */
                //d3.select("h2").text(d.properties.formal_en);
                //d3.select(this).attr("class","incident hover");
            })
            .on("mouseout", function(d){
                d3.select("h2").text("null");
                //d3.select(this).attr("class","incident");
            })
            .on("mousemove", function (d, i) {   
                tooltip.move();
                })
                .on("mouseout", function (d, i) {
                //createStuff();
                tooltip.hide();
            });    

            /*.style("fill", function(d) { return color(malariaDataByCountryId[d.adm0_a3_is]); });*/

            /*
            .style("fill", function(d) {
                if (malariaDataByCountryId[d.adm0_a3_is]) {
                    return color(malariaDataByCountryId[d.adm0_a3_is]);
                }
                else {
                    return "#ccc";
                }
                */

        // Update choropleth
      updateChoropleth();
    });
      

  function updateChoropleth() {

    // --> Choropleth implementation

  }

  /*

   for (var i = 0; i < malariaData.length; i++) {
   var o = malariaData[i];
   o.adm0_a3_is = o.Code;
   delete o.Code;
   }


  for (var i=0; i < malariaData.length; i++) {
      console.log(i);
      var malariaCountry = malariaData[i].Code;
      console.log("test:" + malariaCountry);
      var malariaValue = malariaData[i].UN_population;

      for (var j = 0; j < africa[j].length; j++) {
          var jsonCountry = africa[j].properties.adm0_a3_is;
          if (malariaCountry = jsonCountry) {
              africa[j].properties.value = malariaValue;
              break;
          };
      }
  };
  */
}